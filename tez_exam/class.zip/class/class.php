<?php
    date_default_timezone_set('Asia/Kolkata');
    $now = date('Y-m-d H:i:s');
    $today = date('Y-m-d');

    class Exam{
    
    // Department

        function verify_code($code){
            global $connect;
            $sql = " SELECT * FROM department WHERE Dept_code = '$code' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                return true;
            } return false;
        }

        function create_department($code, $name){
            global $connect;

            if($this->verify_code($code) === true){
                $sql = " UPDATE `department` SET `Dept_name`='$name' WHERE Dept_code = '$code' ";
                if($connect->query($sql)){
                    return ['status' => true, 'msg' => 'Department successfully updated'];
                } else {
                    return ['status' => false, 'msg' => 'Failed to update department'];
                }
            } else {
                $sql = " INSERT INTO `department`(`Dept_code`, `Dept_name`) VALUES ('$code','$name') ";
                if($connect->query($sql)){
                    return ['status' => true, 'msg' => 'Department successfully added'];
                } else {
                    return ['status' => false, 'msg' => 'Failed to add department'];
                }
            }
        }

        function list_department($searchquery){
            global $connect;
            $sql = " SELECT Dept_code as id, Dept_name FROM `department`WHERE Dept_code like '%$searchquery%' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $array[] = $row;
                } return ['status' => true, 'data' => $array];
            } else {
                return ['status' => false, 'msg' => 'Not found any department.'];
            }
        }

        function department_detail($code){
            global $connect;
            $sql = " SELECT * FROM `department` WHERE Dept_code = '$code' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                $row = $result->fetch_assoc();
                return ['status' => true, 'data' => $row];
            } else {
                return ['status' => false, 'msg' => 'Not found any detail'];
            }
        }

        function delete_department($code){
            global $connect;
            $sql = " DELETE FROM `department` WHERE Dept_code = '$code' ";
            if($connect->query($sql)){
                return ['status' => true, 'msg' => 'Department successfully deleted'];
            } else {
                return ['status' => false, 'msg' => 'Failed to delete department'];
            }
        }

    // Programme

        function verify_program_code($procode){
            global $connect;
            $sql = " SELECT * FROM `programme` WHERE Programme_code = '$procode' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                return true;
            } return false;
        }

        function create_program($deptcode, $procode, $name, $semester){
            global $connect;
            if($this->verify_program_code($procode) === true){
                $sql = " UPDATE `programme` SET `Programme_name`='$name',`Number_of_Semester`='$semester' WHERE Programme_code = '$procode' AND Dept_code = '$deptcode' ";
                if($connect->query($sql)){
                    return ['status' => true, 'msg' => 'Programme successfully updated.'];
                } else {
                    return ['status' => false, 'msg' => 'Failed to update programme.'];
                }
            } else {
                $sql = " INSERT INTO `programme`(`Programme_code`, `Programme_name`, `Number_of_Semester`, `Dept_code`) VALUES ('$procode','$name','$semester','$deptcode') ";
                if($connect->query($sql)){
                    return ['status' => true, 'msg' => 'Programme successfully created.'];
                } else {
                    return ['status' => false, 'msg' => 'Failed to create programme.'];
                }
            }
        }

        function list_programs($searchquery){
            global $connect;
            $sql = "SELECT Programme_code as id, Programme_name as proname, Number_of_Semester as sem, Dept_code FROM `programme` WHERE Programme_code like '%$searchquery%' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $array[] = $row;
                } return ['status' => true, 'data' => $array];
            } else {
                return ['status' => false, 'msg' => 'No Record is present Yet!'];
            }
        }

        function program_detail($procode){
            global $connect;
            $sql = " SELECT Programme_code as id, Programme_name as proname, Number_of_Semester as sem, Dept_code FROM `programme` WHERE Programme_code = '$procode' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                $row = $result->fetch_assoc();
                return ['status' => true, 'data' => $row];
            } else {
                return ['status' => false, 'msg' => 'Not found any detail.'];
            }
        }

        function delete_programme($procode){
            global $connect;
            $sql = " DELETE FROM `programme` WHERE Programme_code = '$procode' ";
            if($connect->query($sql)){
                return ['status' => true, 'msg' => 'Programme successfully deleted.'];
            } else {
                return ['status' => false, 'msg' => 'Failed to delete programme.'];
            }
        }


    // Course

        function verify_course_code($coursecode){
            global $connect;
            $sql = " SELECT * FROM `course` WHERE Course_code = '$coursecode' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                return true;
            } return false;
        }

        function create_course_code($coursecode, $name, $credit, $deptcode){
            global $connect;
            if($this->verify_course_code($coursecode) === true){
                $sql = " UPDATE `course` SET `Course_code`='$coursecode',`Course_name`='$name',`Credit`='$credit',`Dept_code`='$deptcode' WHERE Course_code = '$coursecode' AND Dept_code = '$deptcode' ";
                if($connect->query($sql)){
                    return ['status' => true, 'msg' => 'Course successfully updated.'];
                } else {
                    return ['status' => false, 'msg' => 'Failed to update course.'];
                }
            } else {
                $sql = " INSERT INTO `course`(`Course_code`, `Course_name`, `Credit`, `Dept_code`) VALUES ('$coursecode','$name','$credit','$deptcode') ";
                if($connect->query($sql)){
                    return ['status' => true, 'msg' => 'Course successfully created.'];
                } else {
                    return ['status' => false, 'msg' => 'Failed to create course.s'];
                }
            }
        }

        function list_courses($searchquery){
            global $connect;
            $sql = "SELECT Course_code as id, Course_name as cname, Credit as cradit, Dept_code as deptcode FROM `course` ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $array[] = $row;
                } return ['status' => true, 'data' => $array];
            } else {
                return ['status' => false, 'msg' => 'Created course will appear here.'];
            }
        }

        function course_detail($coursecode){
            global $connect;
            $sql = " SELECT * FROM `course` WHERE Course_code = '$coursecode' ";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                $row = $result->fetch_assoc();
                return ['status' => true, 'data' => $row];
            } else {
                return ['status' => false, 'msg' => 'Not found any detail.'];
            }
        }

        function delete_course($coursecode){
            global $connect;
            $sql = " DELETE FROM `course` WHERE Course_code = '$coursecode' ";
            if($connect->query($sql)){
                return ['status' => true, 'msg' => 'Course successfully deleted.'];
            } else {
                return ['status' => false, 'msg' => 'Failed to delete course.'];
            }
        } 

    // Session
    
        function list_session(){
            global $connect;
            $sql = "SELECT ID as id, Term as term, Year as year FROM `semester`";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $array[] = $row;
                } return ['status' => true, 'data' => $array];
            } else {
                return ['status' => false, 'msg' => 'Created course will appear here.'];
            }
        }
    // Student
    
        function list_student(){
            global $connect;
            $sql = "SELECT Enrollment_No as id, Name as name, Programme_code as procode, Dept_code as deptcode FROM `student`";
            $result = $connect->query($sql);
            if($result -> num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $array[] = $row;
                } return ['status' => true, 'data' => $array];
            } else {
                return ['status' => false, 'msg' => 'Created course will appear here.'];
            }
        }


    } // End of the Exam class
?>